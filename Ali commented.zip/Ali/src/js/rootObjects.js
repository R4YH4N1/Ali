// Global index file
// Creating the namespace 
var MohammedAliApp_MUA = {
    // Global functions live here
    f: {
        // Page references
        p: {
            // Defining the index page
            indexPage: null,
        },
        // General other global stuff
        g:{

        },
        // Objects, e.g: vueRef: null,
    o: {
        
        
}
    }
}