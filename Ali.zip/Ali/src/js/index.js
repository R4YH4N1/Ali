MohammedAliApp_MUA.f.p.indexPage = new Vue({
    el: '#page',
    data: {
        isLogin: false,

    },
    methods: {
        logSwitch: function() {
            this.isLogin = !this.isLogin;
        }
    }

})
