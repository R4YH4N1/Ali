var MohammedAliApp_MUA = {
    f: {
        p: {
            indexPage: null,
        },
        g:{

        },
    o: {
        
        
}
    }
}