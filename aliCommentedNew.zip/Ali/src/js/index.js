// Namespacing
MohammedAliApp_MUA.f.p.indexPage = new Vue({
    // Link to main html page
    el: '#page',
    // Temporary variable storage, permanent global variables are stored in rootObjects.js ande referenced by 'MohammedAliApp_MUA.filePath
    data: {
        isLogin: false,

    },
    // Functions go in here, in object syntax ( functionName: function () {})
    methods: {
        // This function switches between log in and sign up
        logSwitch: function() {
            // Alters the login variable state defined in data
            this.isLogin = !this.isLogin;
        }
    }

})
